autoheader
aclocal
autoconf
automake --add-missing
./configure
make
